import { View, Text } from 'react-native'
import React from 'react'

const TempScreen = () => {
  return (
    <View>
      <Text>TempScreen</Text>
    </View>
  )
}

export default TempScreen