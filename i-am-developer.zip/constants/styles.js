export const Colors = {
    authInputBoxBackground: '#f9beda',
    authButtonBackground: '#c30b64',
    authBackground: '#610440',
    error100: '#fcdcbf',
    error500: '#f37c13',
  }