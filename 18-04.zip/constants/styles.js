export const Colors = {
    authText: "#F7B84B",
    authInputBoxBackground: '#f9beda',
    authButtonBackground: '#c30b64',
    authBackground: '#000000',
    error100: '#fcdcbf',
    // error500: '#f37c13',
    errorText: "red",
  }