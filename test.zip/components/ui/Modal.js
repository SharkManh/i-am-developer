// import React from 'react';
// import { Modal, View, Text, Button, StyleSheet } from 'react-native';

// const Modal = ({ isVisible, onClose, children }) => {
//   return (
//     <Modal
//       animationType="slide"
//       transparent={true}
//       visible={isVisible}
//     >
//       <View style={styles.overlay}>
//         <View style={styles.modal}>
//           <Text>Notification</Text>
//           <Button title="Close" onPress={onClose} />
//         </View>
//       </View>
//     </Modal>
//   );
// };

// export default Modal;

// const styles = StyleSheet.create({
//   overlay: {
//     flex: 1,
//     backgroundColor: 'rgba(0, 0, 0, 0.3)',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   modal: {
//     backgroundColor: 'white',
//     padding: 20,
//     borderRadius: 10,
//   },
// });